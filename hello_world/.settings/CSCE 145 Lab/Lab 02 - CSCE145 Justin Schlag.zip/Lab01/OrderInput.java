//Copyright 2024 Justin Schlag 

import java.util.Scanner; 

public class OrderInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Scanner to read input from input text
		Scanner console = new Scanner(System.in);

		//reads three integer values from the input
		int int1 = console.nextInt();
		
		int int2 = console.nextInt();
		
		int int3 = console.nextInt();
		
		//reads three double values from the input 
		double double1 = console.nextDouble();
		
		double double2 = console.nextDouble();
		
		double double3 = console.nextDouble();
		
		//reads three string values from the input 
		String string1 = console.next();
		
		String string2 = console.next();
		
		String string3 = console.next();
		
		//No output in this class, just getting the hang of the scanner and pulling values from input text 
		
		console.close();
		
		
		
	}

}
